#!/usr/bin/env python3
"""
csv2webstations.py — конвертер плейлиста автомагнитолы из CSV в формат WebStations.txt

Формат входного CSV (без заголовка, разделитель — TAB):
    Название<TAB>URL<TAB>ovol
    Шлягер FM<TAB>https://cast.fex.net/shanson_l<TAB>0

Формат выходного TXT (по одной JSON-строке на станцию, CRLF в конце строки):
    {"Name":"Шлягер FM","URL":"https://cast.fex.net","File":"/shanson_l","Port":"443","ovol":"0"}

Правила разбора URL (выведены из образца WebStations.txt):
  - если схема https -> поле "URL" = "https://<host>" (порт по умолчанию 443)
  - если схема http  -> поле "URL" = "<host>" без префикса http:// (порт по умолчанию 80)
  - если в адресе явно указан порт (host:port) — используется он
  - "File" = путь (+ ?query, + #fragment), если пуст — "/"
  - список станций дополняется пустыми слотами до TOTAL_SLOTS (по умолчанию 256,
    как в примере WebStations.txt)

Использование:
    python3 csv2webstations.py playlist.csv WebStations.txt
    python3 csv2webstations.py playlist.csv WebStations.txt --slots 256
"""

import sys
import csv
import argparse
from urllib.parse import urlsplit

BLANK_LINE = '{"Name":"","URL":"","File":"","Port":"0","ovol":"0"}'


def clean_url(raw: str) -> str:
    """Убирает случайный мусор после первого пробела (битые строки вида
    'http://host:8000/path Request Method: GET')."""
    raw = raw.strip()
    return raw.split(" ")[0]


def split_url(raw_url: str):
    """Возвращает (url_field, file_field, port_field) по правилам образца."""
    raw_url = clean_url(raw_url)

    # если схема не указана - считаем http
    if "://" not in raw_url:
        raw_url = "http://" + raw_url

    parts = urlsplit(raw_url)
    scheme = parts.scheme.lower()
    host = parts.hostname or ""
    explicit_port = parts.port

    if scheme == "https":
        default_port = 443
        url_field = f"https://{host}"
    else:
        default_port = 80
        url_field = host

    port = explicit_port if explicit_port else default_port

    file_field = parts.path or "/"
    if parts.query:
        file_field += "?" + parts.query
    if parts.fragment:
        file_field += "#" + parts.fragment

    return url_field, file_field, str(port)


def convert(input_path: str, output_path: str, total_slots: int):
    rows = []
    with open(input_path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f, delimiter="\t")
        for row in reader:
            if not row or not any(cell.strip() for cell in row):
                continue
            name = row[0].strip() if len(row) > 0 else ""
            raw_url = row[1].strip() if len(row) > 1 else ""
            ovol = row[2].strip() if len(row) > 2 else "0"

            if not name and not raw_url:
                continue

            if raw_url:
                url_field, file_field, port_field = split_url(raw_url)
            else:
                url_field, file_field, port_field = "", "", "0"

            name_escaped = name.replace('"', '\\"')
            line = (
                f'{{"Name":"{name_escaped}","URL":"{url_field}",'
                f'"File":"{file_field}","Port":"{port_field}","ovol":"{ovol}"}}'
            )
            rows.append(line)

    if total_slots and len(rows) < total_slots:
        rows.extend([BLANK_LINE] * (total_slots - len(rows)))
    elif total_slots and len(rows) > total_slots:
        print(
            f"Предупреждение: станций ({len(rows)}) больше, чем слотов ({total_slots}). "
            f"Лишние записи не будут обрезаны.",
            file=sys.stderr,
        )

    with open(output_path, "w", newline="\r\n", encoding="utf-8") as f:
        for line in rows:
            f.write(line + "\n")

    print(f"Готово: {len(rows)} строк записано в {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Конвертер playlist.csv -> WebStations.txt")
    parser.add_argument("input", help="путь к входному CSV файлу")
    parser.add_argument("output", help="путь к выходному TXT файлу")
    parser.add_argument(
        "--slots",
        type=int,
        default=256,
        help="общее число слотов в итоговом файле (по умолчанию 256, как в образце). "
        "0 — не дополнять пустыми слотами.",
    )
    args = parser.parse_args()
    convert(args.input, args.output, args.slots)


if __name__ == "__main__":
    main()
